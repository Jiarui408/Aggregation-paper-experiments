namespace Aggregation_paper_experiments
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			bool aggregate_solve = true;
			string logFilePath = @"D:\repository\Aggregation-paper-experiments\Aggregation-paper-experiments\bin\Debug\net8.0-windows\SND_instances\output_log_SND.txt";
			using (StreamWriter logFile = new StreamWriter(logFilePath, true))
			{
				for (int i = 1; i <= 15; i++)
				{
					SND_DataStructure sd = null;
					SND_Solver solver = null;

					try
					{
						sd = new SND_DataStructure();
						sd.ReadDataAggregationPaper(i);
						sd.FindAggregation();

						solver = new SND_Solver();

						if (aggregate_solve)
						{
							solver.Gurobi_aggregate_solve_SND(sd);
							solver.Gurobi_disaggregate_solve_SND(sd);
						}
						else
						{
							solver.Gurobi_original_solve_SND(sd);
						}

						logFile.WriteLine("instance" + i + "============================================================================");
						logFile.WriteLine("nodes-arcs-commodities:" + sd.nodes.Count() + "-" + sd.arcs.Count() + "-" + sd.demands.Count());
						logFile.WriteLine("aggregatedflows:" + sd.aggregate_flows.Count());
						logFile.WriteLine("aggregation solving time:" + sd.aggregation_solving_time);
						logFile.WriteLine("disaggregation solving time:" + sd.disaggregation_solving_time);
						logFile.WriteLine("aggregation solving gap:" + sd.aggregation_gap);
						logFile.WriteLine("original solving time:" + sd.original_solving_time);
						logFile.WriteLine("original solving gap:" + sd.original_gap);
						logFile.WriteLine();
					}
					catch (OutOfMemoryException ex)
					{
						logFile.WriteLine("instance" + i + " failed due to **OUT OF MEMORY**: " + ex.Message);
					}
					catch (Exception ex)
					{
						logFile.WriteLine("instance" + i + " failed due to unexpected error: " + ex.Message);
					}
					finally
					{
						solver = null;
						sd = null;
						GC.Collect();
						GC.WaitForPendingFinalizers();
						logFile.Flush();
					}
				}
			}

		}

		private void Form1_Load(object sender, EventArgs e)
		{

		}

		private void button2_Click(object sender, EventArgs e)
		{
			bool aggregate_solve = true;
			string logFilePath = @"D:\repository\Aggregation-paper-experiments\Aggregation-paper-experiments\bin\Debug\net8.0-windows\VCP_instances\output_log_VCP.txt";

			using (StreamWriter logFile = new StreamWriter(logFilePath, true))
			{
				for (int i = 1; i <= 15; i++)
				{
					VCP_DataStructure vcp = null;
					VCP_Solver solve = null;

					try
					{
						vcp = new VCP_DataStructure();
						vcp.ReadDataAggregationPaper(i);
						vcp.ConstructNetwork();

						solve = new VCP_Solver();

						if (aggregate_solve)
						{
							solve.Gurobi_aggregate_solve_VCP(vcp);
							solve.Gurobi_disaggregate_solve_VCP(vcp);
						}
						else
						{
							solve.Gurobi_original_solve_VCP(vcp);
						}

						logFile.WriteLine("instance" + i + "============================================================================");
						logFile.WriteLine("nodes-arcs-commodities:" + vcp.nodes.Count() + "-" + vcp.arcs.Count() + "-" + vcp.demands.Count());
						logFile.WriteLine("aggregatedflows:" + 1);
						logFile.WriteLine("aggregation solving time:" + vcp.aggregation_solving_time);
						logFile.WriteLine("disaggregation solving time:" + vcp.disaggregation_solving_time);
						logFile.WriteLine("aggregation solving gap:" + vcp.aggregation_gap);
						logFile.WriteLine("original solving time:" + vcp.original_solving_time);
						logFile.WriteLine("original solving gap:" + vcp.original_gap);
						logFile.WriteLine();
					}
					catch (OutOfMemoryException ex)
					{
						logFile.WriteLine("instance" + i + " failed due to **OUT OF MEMORY**: " + ex.Message);
					}
					catch (Exception ex)
					{
						logFile.WriteLine("instance" + i + " failed due to unexpected error: " + ex.Message);
					}
					finally
					{
						solve = null;
						vcp = null;
						GC.Collect();
						GC.WaitForPendingFinalizers();
						logFile.Flush();
					}
				}
			}

		}

		private void button4_Click(object sender, EventArgs e)
		{
			HISP_MP_DataStructure hd = new HISP_MP_DataStructure();
			hd.GenerateDataForHISPMP();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			bool aggregate_solve = false;
			string logFilePath = @"D:\repository\Aggregation-paper-experiments\Aggregation-paper-experiments\bin\Debug\net8.0-windows\HISP-MP_instances\output_log_HISP-MP.txt";

			using (StreamWriter logFile = new StreamWriter(logFilePath, true))
			{
				for (int i = 2; i <= 150; i++)
				{
					HISP_MP_DataStructure hs = null;
					HISP_MP_Solver solver = null;

					try
					{
						hs = new HISP_MP_DataStructure();
						hs.ReadData(i);
						hs.BuildNetwork();

						solver = new HISP_MP_Solver();

						if (aggregate_solve)
						{
							solver.Gurobi_aggregate_solve_HISPMP(hs);
							solver.Gurobi_disaggregate_solve_HISPMP(hs);
						}
						else
						{
							solver.Gurobi_original_solve_HISPMP(hs);
						}

						logFile.WriteLine("instance" + i + "============================================================================");
						logFile.WriteLine("nodes-arcs-vacancies-intervals:" + hs.DAG_nodes.Count() + "-" + hs.DAG_arcs.Count() + "-" + hs.vacancies.Count() + "-" + hs.intervals.Count());
						logFile.WriteLine("aggregatedflows:" + hs.aggre_flows.Keys.Count());
						logFile.WriteLine("aggregation solving time:" + hs.aggregation_solving_time);
						logFile.WriteLine("disaggregation solving time:" + hs.disaggregation_solving_time);
						logFile.WriteLine("aggregation solving gap:" + hs.aggregation_gap);
						logFile.WriteLine("original solving time:" + hs.original_solving_time);
						logFile.WriteLine("original solving gap:" + hs.original_gap);
						logFile.WriteLine();
					}
					catch (OutOfMemoryException ex)
					{
						logFile.WriteLine("instance" + i + " failed due to **OUT OF MEMORY**: " + ex.Message);
					}
					catch (Exception ex)
					{
						logFile.WriteLine("instance" + i + " failed due to unexpected error: " + ex.Message);
					}
					finally
					{
						// �ͷ���Դ�����Ի����ڴ�
						solver = null;
						hs = null;
						GC.Collect();
						GC.WaitForPendingFinalizers();
						logFile.Flush(); // ȷ��ÿ�ζ�д��
					}
				}
			}
		}
	}
}
