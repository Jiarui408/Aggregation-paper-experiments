﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Aggregation_paper_experiments
{
	class SND_DataStructure
	{
		//parameters
		public int service_capacity = 29;
		public double service_cost_perlength = 7.93;
		public double demand_arc_cost_perlength = 0.33;
		public int max_service_frequency = 200;

		public double gap = 0.0;
		public int time = 3600;

		public HashSet<string> origins = new HashSet<string>();
		public HashSet<string> destinations = new HashSet<string>();

		//datastructure
		public Dictionary<int, Demand> demands = new Dictionary<int, Demand>();
		public Dictionary<string, AggregateFlow> aggregate_flows = new Dictionary<string, AggregateFlow>();
		public Dictionary<string, Node> nodes = new Dictionary<string, Node>();
		public Dictionary<string, Arc> arcs = new Dictionary<string, Arc>();
		public Dictionary<string, Dictionary<string, int>> aggregateflow_arc_quanity = new Dictionary<string, Dictionary<string, int>>();

		//recording data in solving
		public double aggregation_solving_time = 0.0;
		public double disaggregation_solving_time = 0.0;
		public double original_solving_time = 0.0;
		public double aggregation_gap = 100.0;
		public double original_gap = 100.0;

		#region Readdata and construct the network
		public void ReadDataAggregationPaper(int i)
		{
			FileStream fs1 = new FileStream("SND_instances\\" + "week_" + i.ToString() + ".csv", FileMode.Open);
			StreamReader sr1 = new StreamReader(fs1);
			sr1.ReadLine();
			string NoteData1 = sr1.ReadLine();
			int commodity_key = 1;
			while (NoteData1 != null && NoteData1 != "")
			{
				string[] data = new string[4];
				data = NoteData1.Split(',');
				Demand d = new Demand();
				d.name = commodity_key;
				d.startstation = data[0].ToString();
				d.endstation = data[1].ToString();
				d.amount = Convert.ToInt32(data[2]);
				d.distance = Convert.ToInt32(data[3]);
				demands[commodity_key] = d;

				origins.Add(d.startstation);
				destinations.Add(d.endstation);

				Buildnode(d.startstation);
				Buildnode(d.endstation);
				BuildArc(d.startstation, d.endstation, d.distance, false);

				NoteData1 = sr1.ReadLine();
				commodity_key++;
			}
			sr1.Close();
			fs1.Close();

			void Buildnode(string name)
			{
				if (nodes.ContainsKey(name) == false)
				{
					Node n = new Node();
					n.name = name;
					nodes[name] = n;
				}
			}
			void BuildArc(string name1, string name2, int distance, bool two_direction)
			{
				Arc a1 = new Arc();
				a1.name = name1 + "-" + name2;
				a1.outnode = nodes[name1];
				a1.innode = nodes[name2];
				a1.length = distance;
				nodes[name1].outarc.Add(a1);
				nodes[name2].inarc.Add(a1);
				arcs[a1.name] = a1;

				if (two_direction == true)
				{
					Arc a2 = new Arc();
					a2.name = name2 + "-" + name1;
					a2.outnode = nodes[name2];
					a2.innode = nodes[name1];
					a2.length = distance;
					arcs[a2.name] = a2;
					nodes[name2].outarc.Add(a2);
					nodes[name1].inarc.Add(a2);
				}
			}
		}
		public void FindAggregation()
		{
			foreach (var v in demands)
			{
				string origin = v.Value.startstation;
				if (aggregate_flows.ContainsKey(origin) == false)
				{
					AggregateFlow af = new AggregateFlow();
					af.origin = origin;
					aggregate_flows[origin] = af;
				}
				aggregate_flows[origin].ori_amount = aggregate_flows[origin].ori_amount + v.Value.amount;
				aggregate_flows[origin].including_commodities.Add(v.Value.name);
				if (aggregate_flows[origin].des_amount.ContainsKey(v.Value.endstation) == false)
					aggregate_flows[origin].des_amount[v.Value.endstation] = 0;
				aggregate_flows[origin].des_amount[v.Value.endstation] = aggregate_flows[origin].des_amount[v.Value.endstation] + v.Value.amount;
			}
		}
		#endregion
	}

	class Arc
	{
		public string name;
		public string mark;
		public double length;
		public Node outnode;
		public Node innode;
		public int capacity;
		public double roll = 0.0;
		public string belonging_trainarc_name = "";
		public List<string> including_freightarcs = new List<string>();
		public HashSet<string> related_resourcenames = new HashSet<string>();

		//for HISP-MP
		public int intlname = new int();
		public int hier = new int();
		public int profit = 0;
		public int vacancyname = new int();
	}

	class Node
	{
		public string name;
		public string nodestation;
		public int nodetime;
		public List<Arc> inarc = new List<Arc>();
		public List<Arc> outarc = new List<Arc>();
		public int state;
		public string mark;
		public string topomark = "unvisited";
		public int order = -1;
		public string before = "";
		public ConcurrentDictionary<string, string> path = new ConcurrentDictionary<string, string>();
		public ConcurrentDictionary<string, double> dis = new ConcurrentDictionary<string, double>();
	}

	class Demand
	{
		public int name;
		public int amount;
		public int payment;
		public string startstation;
		public int starttime;
		public string endstation;
		public int distance;
		public int endtime;
		public List<int> path_ids = new List<int>();
		public HashSet<string> path_names = new HashSet<string>();
	}

	class Path
	{
		public int id = new int();
		public string name = "";
		public HashSet<string> included_arcs = new HashSet<string>();
		public double cost = 0.0;
	}

	class DataBatch()
	{
		public int ins;
		public int time;
		public double obj;
	}

	class Feature
	{
		public int node_num = new int();
		public int arc_num = new int();
		public int flow_num = new int();
	}

	class AggregateFlow
	{
		public int name = new int();
		public string origin = "";
		public int ori_amount = 0;
		public Dictionary<string, int> des_amount = new Dictionary<string, int>();
		public HashSet<int> including_commodities = new HashSet<int>();
	}
}
