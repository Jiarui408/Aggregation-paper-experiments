Code for "An Exact Aggregation-Disaggregation Algorithm for a Class of Mixed-Integer Programs"

This repository contains the implementation and experimental code for solving three classical optimization problems using an aggregation-disaggregation algorithm:
	SND: Service Network Design
	VCP: Vehicle Circulation Problem
	HISP-MP: Hierarchical Interval Scheduling with Maximal Profit

Environment Setup
	Platform: Windows 10+
	IDE: Visual Studio 2022
	Runtime: .NET 8.0 or later
	Solver: Gurobi 11.0 with .NET bindings
	Language: C#

Project Structure
	Aggregation-paper-experiments/
	├──bin/Debug/net8.0-windows/
	│   ├── SND_instances/            # Test instances for SND
	│   ├── VCP_instances/            # Test instances for VCP
	│   ├── HISP-MP_instances/        # Test instances for HISP-MP
	│
	├── SND_DataStructure.cs          # Data structure and model for SND
	├── VCP_DataStructure.cs          # Data structure and model for VCP
	├── HISP_MP_DataStructure.cs      # Data structure and model for HISP-MP
	│
	├── SND_Solver.cs                 # Aggregation/disaggregation/full model for SND
	├── VCP_Solver.cs                 # Solver logic for VCP
	├── HISP_MP_Solver.cs             # Solver logic for HISP-MP
	│
	├── Form1.cs                      # GUI interface and experiment controller

How to Run the Code
	1. Open the solution in Visual Studio 2022.
	2. Build and run the project.
	3. In the GUI, use the following buttons:
		Button 1: Run SND experiments (15 instances)
		Button 2: Run VCP experiments (15 instances)
		Button 3: Run HISP-MP experiments (150 instances)
		Button 4: Generate HISP-MP data
	Each experiment:
		Loads the corresponding instance
		Constructs aggregated and full models
		Solves with Gurobi
		Logs performance and solution quality
	Output
		Results are printed to the console which includes:
			Problem size: number of nodes, arcs, jobs, machines, etc.
			Aggregated vs. original model size (variables and constraints)
			Solving times for:
				Aggregated model
				Disaggregation step
				Original model
			Optimality gaps reported by Gurobi